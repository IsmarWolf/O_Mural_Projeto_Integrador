Piii.js
=======

> Um avançado filtro de palavrões.

***

**Este projeto não é mais mantido. [Leia aqui a nota de arquivamento](https://github.com/portujs/piii.js/issues/8).**

***

[![Build Status](https://travis-ci.org/piiijs/piii.js.svg?branch=master)](https://travis-ci.org/piiijs/piii.js)
[![Doar](https://img.shields.io/badge/paypal-doar-179bd7.svg?logo=paypal&style=flat&logoColor=blue)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=3WZ447WCJ54XG&source=url)

[![NPM](https://nodei.co/npm/piii.png?mini=true)]()

Veja a documentação em &lt;https://git.io/piii-docs&gt;.

Características
---------------

Você poderá:

* :metal: Ignorar se as letras estão em maiúsculas ou minúsculas.
* :wine_glass: Ignorar o uso de qualquer tipo de acentuação.
* :nail_care: Gerênciar um alfabeto personalizado (veja sobre [*leet*](https://goo.gl/MLRHcB)).
* :dancers: Ignorar letras repetidas.
* :lipstick: Criar um filtro personalizado.
* :muscle: Manipular o palavrão antes de filtrá-lo.

Licença
-------

MIT &copy; [Matheus Alves](https://git.io/v3PZ9)
