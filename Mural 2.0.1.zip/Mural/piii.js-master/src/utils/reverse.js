"use strict";

function reverse(array) {
  return Array.from(array).reverse();
}

module.exports = reverse;
