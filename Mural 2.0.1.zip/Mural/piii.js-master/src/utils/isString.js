"use strict";

function isString(value) {
  return typeof value === "string";
}

module.exports = isString;
