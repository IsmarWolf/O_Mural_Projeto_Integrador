"use strict";

function sort(array) {
  return Array.from(array).sort();
}

module.exports = sort;
