(function(win, doc) {
    'use strict';

    // Configuração do Piii.js
    const piii = new Piii({
        filters: [
            [
                'merda', 'bosta', 'foder', 'abestado', 'aborto', 'anus', 'arrombada', 'arrombado',
                'babaca', 'bacanal', 'baitola', 'bicha', 'boceta', 'boiola', 'boquete', 'bronha',
                'buceta', 'bunda', 'burra', 'burro', 'cachorra', 'cachorro', 'cadela', 'cagado',
                'caralho', 'corno', 'cu', 'cuzao', 'debil', 'escrota', 'escroto', 'estupida',
                'estupido', 'feia', 'feio', 'foda', 'gay', 'idiota', 'imbecil', 'ladrao', 'leprosa',
                'macaca', 'macaco', 'otaria', 'otario', 'pau', 'pica', 'piranha', 'piroca',
                'porra', 'puta', 'puto', 'rabo', 'safada', 'safado', 'tarada', 'tarado', 'troxa',
                'vaca', 'vagabunda', 'vagabundo', 'veado', 'viado', 'xoxota', 'xana', 'xota', 'bosta',
                'brioco', 'boqueteira', 'boqueteiro', 'bucetao', 'bunduda', 'cagalhao', 'cagao',
                'cuzinho', 'perereca', 'punheta', 'rachada', 'siririca', 'xexeca', 'xibiu', 'chota',
                'corna', 'cornuda', 'culhao', 'fedida', 'fedido', 'gonorrea', 'grelo', 'leproso',
                'mijada', 'nojenta', 'nojento', 'pentelho', 'prostibulo', 'rabudao', 'sacana', 'viadao',
                
                    
            ]
        ],
        aliases: {
            a: ['@', '4', 'á', 'à', 'ã', 'â'],
            e: ['3', 'é', 'ê'],
            i: ['1', 'í'],
            o: ['0', 'ó', 'õ', 'ô','u'],
            u: ['v', 'ú', 'ü']
        },
        censor: '****'
    });
    

    // Ajax do form
    if (doc.querySelector('#form')) {
        let form = doc.querySelector('#form');
        function sendForm(event) {
            event.preventDefault();
            let data = new FormData(form);
            
            // Filtra a mensagem antes de enviar
            let mensagem = data.get('mensagem');
            if (mensagem) {
                console.log('Mensagem original:', mensagem); // Debug
                let mensagemFiltrada = piii.filter(mensagem);
                console.log('Mensagem filtrada:', mensagemFiltrada); // Debug
                data.set('mensagem', mensagemFiltrada);
            }

            let ajax = new XMLHttpRequest();
            let token = doc.querySelector('input[name="csrfmiddlewaretoken"]').value;

            ajax.open('POST', form.action);
            ajax.setRequestHeader('X-CSRFToken', token);

            ajax.onreadystatechange = function() {
                if (ajax.status === 200 && ajax.readyState === 4) {
                    let result = doc.querySelector('#result');
                    result.innerHTML = 'Mensagem enviada com sucesso!';
                    result.classList.add('alert');
                    result.classList.add('alert-success');

                    form.reset();

                    setTimeout(function() {
                        window.location.href = '/mural';
                    }, 2000);
                }
            }
            ajax.send(data);
        }
        form.addEventListener('submit', sendForm, false);
    }
})(window, document);