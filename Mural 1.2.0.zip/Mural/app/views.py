from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.models import User
from .models import Mensagem
from .forms import MensagemForm, RegistroForm

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('mural')
    return render(request, 'login.html')

def registro_view(request):
    if request.method == 'POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = RegistroForm()
    return render(request, 'registro.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def home(request):
    return render(request, 'index.html')

@login_required
def mural(request):
    mensagens = Mensagem.objects.all().order_by('-data')
    return render(request, 'mural.html', {'mensagens': mensagens})

@login_required
def form(request):
    if not request.user.is_superuser:
        # Verifica se o usuário já postou uma mensagem
        if Mensagem.objects.filter(autor=request.user).exists():
            return redirect('mural')
    
    if request.method == 'POST':
        form = MensagemForm(request.POST)
        if form.is_valid():
            mensagem = form.save(commit=False)
            mensagem.nome = request.user.username
            mensagem.autor = request.user
            mensagem.save()
            return redirect('mural')
    else:
        form = MensagemForm()
    return render(request, 'form.html', {'form': form})

@login_required
def deletar_mensagem(request, mensagem_id):
    if request.user.is_superuser:
        mensagem = get_object_or_404(Mensagem, id=mensagem_id)
        mensagem.delete()
    return redirect('mural')