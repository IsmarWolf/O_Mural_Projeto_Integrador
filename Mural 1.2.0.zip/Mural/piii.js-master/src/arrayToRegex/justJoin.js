"use strict";

function justJoin(value) {
  return `(${value.join("")})`;
}

module.exports = justJoin;
