from django.contrib import admin
from django.urls import path
from app.views import home, mural, form, login_view, registro_view, logout_view, deletar_mensagem

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('mural/', mural, name='mural'),
    path('form/', form, name='form'),
    path('login/', login_view, name='login'),
    path('registro/', registro_view, name='registro'),
    path('logout/', logout_view, name='logout'),
    path('deletar/<int:mensagem_id>/', deletar_mensagem, name='deletar_mensagem'),
]