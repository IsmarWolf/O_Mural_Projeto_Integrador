from django.contrib import admin
from django.urls import path
from app.views import home, mural, form

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('mural/', mural, name='mural'),
    path('form/', form, name='form'),
]