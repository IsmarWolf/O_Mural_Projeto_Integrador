from django.forms import ModelForm
from app.models import Mensagem

class MensagemForm(ModelForm):
    class Meta:
        model = Mensagem
        fields = ['nome', 'mensagem']