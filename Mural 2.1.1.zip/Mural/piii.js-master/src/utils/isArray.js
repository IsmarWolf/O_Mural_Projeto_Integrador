"use strict";

const isArray = Array.isArray;

module.exports = isArray;
