from django.shortcuts import render, redirect
from .models import Mensagem
from .forms import MensagemForm

def home(request):
    return render(request, 'index.html')

def mural(request):
    mensagens = Mensagem.objects.all().order_by('-data')
    return render(request, 'mural.html', {'mensagens': mensagens})

def form(request):
    if request.method == 'POST':
        form = MensagemForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('mural')
    else:
        form = MensagemForm()
    return render(request, 'form.html', {'form': form})